﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeHierachy
{
     abstract class TwoDShape : Shape
    {
        public abstract double GetArea(); //readonly  
    }
    //circle and square

      class Circle(double radius) : TwoDShape //constructor inheriing TwoDShape
    {
        public double Radius { get; } = radius;

        public override double GetArea()
        {
            return Math.PI * Radius * Radius; //formula for area of circle
        }

        public override string GetName()
        {
            return $"Circle with radius {Radius}";
        }
    }

     class Square(double side) : TwoDShape          //constructor inheriing TwoDShape
    {
        private double Side { get; } = side;

        public override double GetArea()
        {
            return Side * Side;         //formula for area of square
        }

        public override string GetName()
        {
            return $"Square with side length {Side}";
        }
                
    }
}
