﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeHierachy
{
     abstract class ThreeDShape : Shape
    {
        public abstract double GetArea(); //readonly
        public abstract double GetVolume();
    }
    //sphere and cube

   
     class Sphere(double radius) : ThreeDShape //constructor inheriing ThreeDShape
    {
        public double Radius { get; } = radius;

        public override double GetArea()
        {
            return 4 * Math.PI * Radius * Radius;   //formula for surface area of sphere
        }

        public override double GetVolume()
        {
            return (4.0 / 3.0) * Math.PI * Radius * Radius * Radius; //formula for volume of sphere
        }

        public override string GetName()
        {
            return $"Sphere with radius {Radius}";
        }
    }

     class Cube(double side) : ThreeDShape //constructor inheriing ThreeDShape
    {
        public double Side { get; } = side;

        public override double GetArea()
        {
            return 6 * Side * Side; //formula for surface area of cube
        }

        public override double GetVolume()
        {
            return Side * Side * Side;      //formula for volume of cube
        }

        public override string GetName()
        {
            return $"Cube with side length {Side}";
        }
    }

}