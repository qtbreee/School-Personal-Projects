﻿namespace ShapeHierachy
{
    public class ShapeHierachyTest
    {
        static void Main(string[] args)
        {
            Shape[] shapes = //array of shape ref
            {
                new Circle(5),
                new Square(4),
                new Sphere(3),
                new Cube(2)
            };


            // Iterate through the array and display properties
            try
            {
                foreach (var shape in shapes)
                {
                    Console.WriteLine($"Shape: {shape.GetName()}");

                    // Check if the shape is a TwoDimensionalShape
                    if (shape is TwoDShape twoDShape)
                    {
                        Console.WriteLine($"Type: 2D Shape");
                        Console.WriteLine($"Area: {twoDShape.GetArea():F2}");
                    }

                    // Check if the shape is a ThreeDimensionalShape
                    else if (shape is ThreeDShape threeDShape)
                    {
                        Console.WriteLine($"Type: 3D Shape");
                        Console.WriteLine($"Surface Area: {threeDShape.GetArea():F2}");
                        Console.WriteLine($"Volume: {threeDShape.GetVolume():F2}");
                    }

                    Console.WriteLine();
                }
            }

            catch (Exception)
            {
                Console.WriteLine("Error");

            }
            
        }
    }
}
