﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private BookTest.BooksDatabaseDataSet dbcontext = new BookTest.BooksDatabaseDataSet();

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'booksDatabaseDataSet.Authors' table. You can move, or remove it, as needed.
            authorsTableAdapter.Fill(booksDatabaseDataSet.Authors);

            dataGridView1.DataSource = authorsBindingSource;

        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            try
            {
                authorsBindingSource.EndEdit();
                authorsTableAdapter.Update(booksDatabaseDataSet.Authors);
                MessageBox.Show("Data saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information); //googled this info
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while saving data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            //select command 
            //871 872 -pull the author by last name
            //
        }

        private void AuthorSearchBar_TextChanged(object sender, EventArgs e)
        {
            
           
            string searchLastName = AuthorSearchBar.Text.Trim();

            if (string.IsNullOrEmpty(searchLastName)) //from the book
            {
                authorsTableAdapter.Fill(booksDatabaseDataSet.Authors); 
            }

            else
            {
                try
                {
                    // Create a DataView for the Authors table
                    //different views of the data stored in a DataTable
                    DataView dv = new DataView(booksDatabaseDataSet.Authors);

                    // Safely format the RowFilter to handle the LIKE query
                    //row filter filters the authors table from the user input in the search bar
                    dv.RowFilter = $"LastName LIKE '{searchLastName}%'";  // Using LIKE for pattern matching

                    // Bind the filtered data to the BindingSource
                    authorsBindingSource.DataSource = dv;
                }
                catch (Exception ex) //catching any possible errors
                {
                    MessageBox.Show($"Error filtering authors: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {

            string searchLastName = AuthorSearchBar.Text.Trim();

            if (string.IsNullOrEmpty(searchLastName))
            {
                MessageBox.Show("Please enter a last name to search.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //create a local 
            var results = booksDatabaseDataSet.Authors
                            .Where(author => author.LastName.StartsWith(searchLastName, StringComparison.OrdinalIgnoreCase)) //looked this up
                            .ToList();

            if (results.Any())
            {
                authorsBindingSource.DataSource = results;
            }
            else
            {
                MessageBox.Show("No authors found.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            authorsBindingSource.DataSource = booksDatabaseDataSet.Authors; // Reset to full dataset
            AuthorSearchBar.Clear(); // Clear the search box
        }
    }
}
