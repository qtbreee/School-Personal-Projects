﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoice
{
    public class Invoice
    {
        //automatic properties
        //partnumber
        //partdescription
        //priceperitem decimal
        //quantity
        public string PartNumber { get; set; }
        public string PartDescription { get; set; }
        //should the int/dec be private??
        private decimal PricePerItem;
        private int Quantity;

        //constructor that ititializs the information
        public Invoice(string partNumber, string partDescription, int quantity, decimal pricePerItem)
        { 
            PartNumber = partNumber;
            PartDescription = partDescription;
            PricePerItem = pricePerItem;
            Quantity = quantity;            
            
        }

        //another set
        public int Qnty
        { 
            get { return Quantity; }
            set
            { 
                //if the value passsed to the set acc is -
                //then the variable should be left unchanged
                if (value > 0)
                    Quantity = value;
                else Quantity = 1;
            }
        }

        public decimal priceperItem
        {
            get { return PricePerItem; }
            set
            {
                
                if (value > 0)
                    PricePerItem = value;
                else PricePerItem = 1;
            }
        }

        //method to calculate invoice amount
        //multiply the quanity by the ppi then return the amount as a decimal
        public decimal InvoiceAmount()
        { 
            return Quantity * PricePerItem;
        }

    }
}
