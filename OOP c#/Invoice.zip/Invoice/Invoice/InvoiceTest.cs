﻿namespace Invoice
{
    public class InvoiceTest
    {
        static void Main(string[] args)
        {
            string partNumber, partDescription;
            int quantity;
            decimal pricePerItem;

            // Display initial invoice details
            Console.WriteLine("Enter the part number");
            partNumber = Console.ReadLine();

            Console.WriteLine("Enter part description");
            partDescription = Console.ReadLine();

            Console.WriteLine("Enter quanity");
            quantity = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter price");
            pricePerItem = Convert.ToDecimal(Console.ReadLine());

            //instiated the invoice object
            Invoice invoice = new Invoice(partNumber, partDescription, quantity, pricePerItem);
            Console.WriteLine("Your order: ");
            Console.WriteLine("Part number: ");
            Console.WriteLine("Part description: {0}", invoice.PartNumber);
            Console.WriteLine("Quantity: {0}", invoice.Qnty);
            Console.WriteLine("Price: {0}", invoice.priceperItem);
            Console.WriteLine("Total: {0:C}", invoice.InvoiceAmount());

            Console.ReadLine();
        }
    }
}
