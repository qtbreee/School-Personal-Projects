﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TemperatureConverter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ConvertBtn_Click(object sender, EventArgs e)
        {
            try                                                               //handle exceptions
            {
                double fahrenheit = Convert.ToDouble(UserTxtbx.Text);                  //converting user input to a double in the text box

                double celsius = (fahrenheit - 32) * 5.0 / 9.0;                         //formula for converting f to c

                DisplayLbl.Text = $"Celsius: " + celsius;                               //displaying the result
            }

            catch (FormatException)
            {
                DisplayLbl.Text = "Please enter a numeric value";                //handle format exceptions, like a word. it should be a numeric value
            }
        }   

    }
}
