﻿using System.Drawing;

namespace Rectangle
{
    class RectangleTest
    {
        static void Main(string[] args)
        {
            //valid dimensions
            Rectangle rectangle = new Rectangle(5.0f, 10.0f);
            Console.WriteLine("Valid dimensions: " + rectangle.GetRectangle());

            //invalid dimensions
            Rectangle rectangleinv = new Rectangle(-5.0f, 25.0f);
            Console.WriteLine("These dimensions are invalid, out of range");

            // Update dimensions
            rectangle.Length = 15.0f;
            rectangle.Width = 12.5f;
            Console.WriteLine("Updated dimensions: " + rectangle.GetRectangle());
        }
    }
}
