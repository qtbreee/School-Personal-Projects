﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rectangle
{
    public class Rectangle
    {
        //defualt to 1
        private float length = 1.0f;
        private float width = 1.0f;


        public Rectangle(float length, float width) //constructor
        {
            Length = length; // Assign to property to include validation
            Width = width; // Assign to property to include validation
        }

        public float Length //length property
        {
            get { return length; }

            set
            {
                if (value > 0.0f && value < 20.0f)
                    length = value;

                else
                    length = 1.0f;



            }
        }

        public float Width //Width property
        {
            get { return width; }

            set
            {
                if (value > 0.0f && value < 20.0f)
                    width = value;
                else
                    width = 1.0f;
                
                
            }
        
        } 
        
        public float Perimeter //Perimeter property
        {
            get { return (Length + Width) * 2; } //this calculates the perimeter

        }

        public float Area //Area property
        {
            get { return (Length * Width); } //this calculates the Area

        }

        //method for displaying the rectangle and its details
        public string GetRectangle()
        {
            return $"The perimeter is {Perimeter:F2} and the area is {Area:F2}";
        }

    }    
}
