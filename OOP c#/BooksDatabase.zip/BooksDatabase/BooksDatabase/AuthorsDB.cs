﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BooksDatabase
{
    public class AuthorsDB
    {
        //methods

        //Insert()
        //INSERT INTO table_name (column1, column2, column3, ...)
        //VALUES(value1, value2, value3, ...);
        public int AddAuthor(string first, string last)
        {
            string sql = "INSERT INTO Authors "; //inserting in the authors table within our books database
            sql += "(FirstName, LastName)"; //when we create the table it will be auto incremented
            sql += " VALUES ";   //cap SQL commands
            //sql += "('David', 'Lee')";          //efficient way other than "(/David/)" NoNo"("David")"
            sql += "(" + first + ", " + last + ")"; //took the values from the parameter and building it to make sense

            int val = 0;
            return val;                     //success or failure, how many rolls were modified
                                            //it can only return an integer for INSERT command
        }
        //Deletes()
        //DELETE FROM table_name WHERE condition;
        // would actually be an UPDATE SQL STATEMENT... 
        public int DeleteAuthor(int id) //unique value. prev example would delete all Lee's
        {
            string SQL = "DELETE FROM Authors WHERE ";
            SQL += id; //string concatenation //don't have to convert it
            int val = 0;
            return val;

        }

        //Purges() //Remove a table or index from your recycle bin and release all of the space associated with the object.


        //Select()
        //SELECT column1, column2, ...
        //SELECT *;      MEANS ALL COLUMNS
        //WHERE id = value;      we tell them what we want
        //WHERE Country='Mexico';
        //FROM table_name;
        public Authors SelectAuthor(int id)
        {
            Authors authors = new Authors();

            string sql = "SELECT * FROM Authors";
            sql += "WHERE AuthorID = " + id;

            authors.AuthorID = id;      //... database cause

            return authors;
        }
        //Updates()
        //UPDATE table_name
        //SET column1 = value1, column2 = value2, ...
        //WHERE condition;

        public int UpdateAuthor(int id, string first, string last)
        {
           string sql = "UPDATE Authors";
            sql += " SET ";
            sql += "FirstName = " + first + ", ";
            sql += "LastName = " + last;

            int val = 0;    
            return val;
        }

      //public int UpdateAuthor(Authors author)
       //{
       //}
    }
}
//896 897 898 899 2 more tables for hw 
//every table is 2 more classes
//insert update select and delete