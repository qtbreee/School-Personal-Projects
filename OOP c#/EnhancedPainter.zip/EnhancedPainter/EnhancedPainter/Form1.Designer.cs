﻿namespace EnhancedPainter
{
    partial class Painter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.SizeBox = new System.Windows.Forms.GroupBox();
            this.MediumRbtn = new System.Windows.Forms.RadioButton();
            this.LargeRbtn = new System.Windows.Forms.RadioButton();
            this.SmallRbtn = new System.Windows.Forms.RadioButton();
            this.ColorBox = new System.Windows.Forms.GroupBox();
            this.BlackRbtn = new System.Windows.Forms.RadioButton();
            this.BlueRbtn = new System.Windows.Forms.RadioButton();
            this.YellowRbtn = new System.Windows.Forms.RadioButton();
            this.RedRbtn = new System.Windows.Forms.RadioButton();
            this.ColorRbtn = new System.Windows.Forms.RadioButton();
            this.SizeBox.SuspendLayout();
            this.ColorBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(294, 23);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1036, 771);
            this.panel1.TabIndex = 0;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Painter_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Painter_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Painter_Mouseup);
            // 
            // SizeBox
            // 
            this.SizeBox.BackColor = System.Drawing.Color.White;
            this.SizeBox.Controls.Add(this.MediumRbtn);
            this.SizeBox.Controls.Add(this.LargeRbtn);
            this.SizeBox.Controls.Add(this.SmallRbtn);
            this.SizeBox.Location = new System.Drawing.Point(12, 339);
            this.SizeBox.Name = "SizeBox";
            this.SizeBox.Size = new System.Drawing.Size(245, 186);
            this.SizeBox.TabIndex = 4;
            this.SizeBox.TabStop = false;
            this.SizeBox.Text = "Size";
            // 
            // MediumRbtn
            // 
            this.MediumRbtn.AutoSize = true;
            this.MediumRbtn.Location = new System.Drawing.Point(7, 81);
            this.MediumRbtn.Name = "MediumRbtn";
            this.MediumRbtn.Size = new System.Drawing.Size(119, 29);
            this.MediumRbtn.TabIndex = 2;
            this.MediumRbtn.TabStop = true;
            this.MediumRbtn.Text = "Medium";
            this.MediumRbtn.UseVisualStyleBackColor = true;
            this.MediumRbtn.CheckedChanged += new System.EventHandler(this.SizeRbtn_CheckedChanged);
            // 
            // LargeRbtn
            // 
            this.LargeRbtn.AutoSize = true;
            this.LargeRbtn.Location = new System.Drawing.Point(7, 131);
            this.LargeRbtn.Name = "LargeRbtn";
            this.LargeRbtn.Size = new System.Drawing.Size(98, 29);
            this.LargeRbtn.TabIndex = 1;
            this.LargeRbtn.TabStop = true;
            this.LargeRbtn.Text = "Large";
            this.LargeRbtn.UseVisualStyleBackColor = true;
            this.LargeRbtn.CheckedChanged += new System.EventHandler(this.SizeRbtn_CheckedChanged);
            // 
            // SmallRbtn
            // 
            this.SmallRbtn.AutoSize = true;
            this.SmallRbtn.Location = new System.Drawing.Point(7, 34);
            this.SmallRbtn.Name = "SmallRbtn";
            this.SmallRbtn.Size = new System.Drawing.Size(96, 29);
            this.SmallRbtn.TabIndex = 0;
            this.SmallRbtn.TabStop = true;
            this.SmallRbtn.Text = "Small";
            this.SmallRbtn.UseVisualStyleBackColor = true;
            this.SmallRbtn.CheckedChanged += new System.EventHandler(this.SizeRbtn_CheckedChanged);
            // 
            // ColorBox
            // 
            this.ColorBox.BackColor = System.Drawing.Color.White;
            this.ColorBox.Controls.Add(this.BlackRbtn);
            this.ColorBox.Controls.Add(this.BlueRbtn);
            this.ColorBox.Controls.Add(this.YellowRbtn);
            this.ColorBox.Controls.Add(this.RedRbtn);
            this.ColorBox.Location = new System.Drawing.Point(12, 23);
            this.ColorBox.Name = "ColorBox";
            this.ColorBox.Size = new System.Drawing.Size(245, 228);
            this.ColorBox.TabIndex = 3;
            this.ColorBox.TabStop = false;
            this.ColorBox.Text = "Color";
            // 
            // BlackRbtn
            // 
            this.BlackRbtn.AutoSize = true;
            this.BlackRbtn.Location = new System.Drawing.Point(7, 178);
            this.BlackRbtn.Name = "BlackRbtn";
            this.BlackRbtn.Size = new System.Drawing.Size(96, 29);
            this.BlackRbtn.TabIndex = 3;
            this.BlackRbtn.Text = "Black";
            this.BlackRbtn.UseVisualStyleBackColor = true;
            this.BlackRbtn.CheckedChanged += new System.EventHandler(this.ColorRbtn_CheckedChanged);
            // 
            // BlueRbtn
            // 
            this.BlueRbtn.AutoSize = true;
            this.BlueRbtn.Location = new System.Drawing.Point(7, 81);
            this.BlueRbtn.Name = "BlueRbtn";
            this.BlueRbtn.Size = new System.Drawing.Size(86, 29);
            this.BlueRbtn.TabIndex = 2;
            this.BlueRbtn.Text = "Blue";
            this.BlueRbtn.UseVisualStyleBackColor = true;
            // 
            // YellowRbtn
            // 
            this.YellowRbtn.AutoSize = true;
            this.YellowRbtn.Location = new System.Drawing.Point(7, 131);
            this.YellowRbtn.Name = "YellowRbtn";
            this.YellowRbtn.Size = new System.Drawing.Size(107, 29);
            this.YellowRbtn.TabIndex = 1;
            this.YellowRbtn.Text = "Yellow";
            this.YellowRbtn.UseVisualStyleBackColor = true;
            this.YellowRbtn.CheckedChanged += new System.EventHandler(this.ColorRbtn_CheckedChanged);
            // 
            // RedRbtn
            // 
            this.RedRbtn.AutoSize = true;
            this.RedRbtn.Location = new System.Drawing.Point(7, 34);
            this.RedRbtn.Name = "RedRbtn";
            this.RedRbtn.Size = new System.Drawing.Size(82, 29);
            this.RedRbtn.TabIndex = 0;
            this.RedRbtn.Text = "Red";
            this.RedRbtn.UseVisualStyleBackColor = true;
            this.RedRbtn.CheckedChanged += new System.EventHandler(this.ColorRbtn_CheckedChanged);
            // 
            // ColorRbtn
            // 
            this.ColorRbtn.Appearance = System.Windows.Forms.Appearance.Button;
            this.ColorRbtn.AutoSize = true;
            this.ColorRbtn.Location = new System.Drawing.Point(32, 257);
            this.ColorRbtn.Name = "ColorRbtn";
            this.ColorRbtn.Size = new System.Drawing.Size(6, 6);
            this.ColorRbtn.TabIndex = 4;
            this.ColorRbtn.TabStop = true;
            this.ColorRbtn.UseVisualStyleBackColor = true;
            this.ColorRbtn.Visible = false;
            // 
            // Painter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1371, 835);
            this.Controls.Add(this.ColorRbtn);
            this.Controls.Add(this.ColorBox);
            this.Controls.Add(this.SizeBox);
            this.Controls.Add(this.panel1);
            this.Name = "Painter";
            this.Text = "Painter";
            this.SizeBox.ResumeLayout(false);
            this.SizeBox.PerformLayout();
            this.ColorBox.ResumeLayout(false);
            this.ColorBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox SizeBox;
        private System.Windows.Forms.RadioButton MediumRbtn;
        private System.Windows.Forms.RadioButton LargeRbtn;
        private System.Windows.Forms.RadioButton SmallRbtn;
        private System.Windows.Forms.GroupBox ColorBox;
        private System.Windows.Forms.RadioButton BlackRbtn;
        private System.Windows.Forms.RadioButton BlueRbtn;
        private System.Windows.Forms.RadioButton YellowRbtn;
        private System.Windows.Forms.RadioButton RedRbtn;
        private System.Windows.Forms.RadioButton ColorRbtn;
    }
}

