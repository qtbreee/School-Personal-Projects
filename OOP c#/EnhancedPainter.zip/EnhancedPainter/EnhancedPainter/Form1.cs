﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace EnhancedPainter
{
    public partial class Painter : Form
    {
        bool ShouldPaint { get; set; } = false; //whether to paint
        Graphics graphics;
        private Color defaultColor = Color.BlueViolet;
        private int brushSize;
        public Painter()
        {
            InitializeComponent();
            panel1.CreateGraphics();
                        
        }
        //should paint when mouse button is pressed down
        private void Painter_MouseDown(object sender, MouseEventArgs e)
        {
            ShouldPaint = true;          //indicate user is dragging the mouse button
        }
        //should paint when mouse button is released
        private void Painter_Mouseup(object sender, MouseEventArgs e)
        {
            ShouldPaint = false;        //indicate user released the mouse button
        }

        private void Painter_MouseMove(object sender, MouseEventArgs e)
        {
            if (ShouldPaint)
            {
                //draw a circle where the mouse pointer is present
                using (Graphics graphics = panel1.CreateGraphics())
                {
                    graphics.FillEllipse(
                        new SolidBrush(defaultColor), e.X, e.Y, brushSize, brushSize);
                }
            }
        }



        private void ColorRbtn_CheckedChanged(object sender, EventArgs e) //loops through the colors from the group box
        {
            if (RedRbtn.Checked)                //if red (so as the other colors) is checked then the default color will become red
                defaultColor = Color.Red;
            else if (BlueRbtn.Checked)
                defaultColor = Color.Blue;
            else if (YellowRbtn.Checked)
                defaultColor = Color.Yellow;
            else if (BlackRbtn.Checked)
                defaultColor = Color.Black;
        }

        private void SizeRbtn_CheckedChanged(object sender, EventArgs e)    //if size(so as the other sizes) is checked then the brush size will become S, M, or L
        {
            if (SmallRbtn.Checked)
                brushSize = 6;
            else if (MediumRbtn.Checked)
                brushSize = 12;
            else if (LargeRbtn.Checked)
                brushSize = 16;
            
        }
    }
}
