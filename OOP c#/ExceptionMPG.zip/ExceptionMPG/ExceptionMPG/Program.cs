﻿namespace ExceptionMPG
{
    public class Program
    {
        static void Main(string[] args)
        {
            double miles;
            double gallons;
            double calculated;   

            try
            {
                Console.Write("Enter miles driven: ");
                miles = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter gallons used: ");
                gallons = Convert.ToDouble(Console.ReadLine());

                calculated = miles / gallons;
                Console.WriteLine("Miles per gallon: " + calculated);
            }

            catch (FormatException fe)
            {
                Console.WriteLine("Enter ONLY a number");
            }
           
            catch (Exception exc)
            {
                Console.WriteLine("Try again");
            }

        }
    }
}
