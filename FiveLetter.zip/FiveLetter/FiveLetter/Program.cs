﻿namespace FiveLetter
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a five letter word: ");
            string word = Console.ReadLine();

            if (word.Length != 5)
            {
                Console.WriteLine("Please enter a five letter word");
                return;
            }

            Console.WriteLine("\n All possible three letter combinations");

            for (int i = 0; i < 5; i++)
            {
                for (int j = i+1; j < 5; j++)
                {
                    for (int k = j+1; k < 5; k++)
                    {
                        Console.WriteLine(" " + word[i] + word[j] + word[k]);
                    }
                }
            }

        }
    }
}
